function validation() {
    var usrid = document.getElementById("Usrid").value;
    var len = usrid.length;
    if (len == 0 || len > 10 || len < 15) {
        alert("userid must contain 10 to 15 digit");
    }

}

function Name() {
    var name = document.getElementById("name").value;
    if (!(name >= 65 && name <= 92)) {
        alert("Allow only Uppercase letters");
    }
}

function email() {
    var email_1 = document.getElementById("Email").value;
    var i = 0;
    if (email_1[i] == '@') {
        alert("Enter valid Email id");
    }
}

function pass() {
    var passward = document.getElementById("pass").value;
    var leng = passward.length;
    if (leng == 0 || leng > 5 || leng < 10) {
        alert("Passward must between 5 to 10");
    }
}

function contact() {
    var no = document.getElementById("Contact").value;
    var len = no.length;
    if (len >= 10 && len <= 12) {
        alert("Enter the correct number");
    }

}

function submit() {
    var r = "Submit";
    var result = r.link("/view/html/register.html");
    document.getElementById("submit").innerHTML = result;
}