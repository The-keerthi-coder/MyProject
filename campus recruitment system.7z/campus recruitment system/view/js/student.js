'use strict'

function name1() {
    var n = document.getElementById("name");
    if (n != "NULL") {
        if (!(n >= 'A' && n <= 'Z')) {
            continue;
        } else
            alert("Enter only uppercase letter");
    }

}

function con() {

    var n = document.getElementById("input");
    if (n.length != 0) {
        if (n.length < 10 && n.length > 12)
            alert("Limited digit only allowed");
    }
}