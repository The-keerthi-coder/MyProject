'use strict'

function login() {
    var r = "Login";
    var result = r.link("/view/html/admin1.html");
    document.getElementById("login1").innerHTML = result;
}

function home() {
    var str = "Home";
    var result = str.link("/view/html/Home.html");
    document.getElementById("home").innerHTML = result;
}