function home() {
    var str = "Home";
    var result = str.link("/view/html/Home.html");
    document.getElementById("home").innerHTML = result;
}


function admin() {
    var str = "Admin";
    var result = str.link("/view/html/admin1.html");
    document.getElementById("admin").innerHTML = result;
}

function Plc_officer() {
    var str = "Placement officer";
    var result = str.link("/view/html/plc.html");
    document.getElementById("Plc_officer").innerHTML = result;
}

function Cmp() {
    var str = "Company";
    var result = str.link("/view/html/company.html");
    document.getElementById("cpy").innerHTML = result;
}

function Stud() {
    var str = "Student";
    var result = str.link("/view/html/student.html");
    document.getElementById("Stud").innerHTML = result;
}

function login() {
    var str = "Login";
    var result = str.link("/view/html/login.html");
    document.getElementById("Log in").innerHTML = result;
}