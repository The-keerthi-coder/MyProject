function login() {
    var r = "Login";
    var result = r.link("/view/html/login.html");
    document.getElementById("Login").innerHTML = result;
}


function reg() {
    var r = "Register";
    var result = r.link("/view/html/register.html");
    document.getElementById("register").innerHTML = result;
}

function Name() {
    var name1 = document.getElementById("name").value;

    if (!(name1 >= 65 && name1 <= 92)) {
        alert("Allow only Uppercase letters");
    }
}

function pass() {
    var passward = document.getElementById("pass").value;
    var leng = passward.length;
    if (leng == 0 || leng > 5 || leng < 10) {
        alert("Passward must between 5 to 10");
    }
}